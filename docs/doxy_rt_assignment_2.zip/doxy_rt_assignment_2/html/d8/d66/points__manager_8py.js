var points__manager_8py =
[
    [ "cbk_get_point", "d8/d66/points__manager_8py.html#aba9b69d4e147bfdd0322ca5b17266c59", null ],
    [ "cbk_point_defined", "d8/d66/points__manager_8py.html#acb1f425f96f297d5b2aca7cc0d542a3f", null ],
    [ "shut_msg", "d8/d66/points__manager_8py.html#a8b43e2972b9e01b6001938b3eb5b3864", null ],
    [ "handler_get_point", "d8/d66/points__manager_8py.html#a9fd69118fff6c111e5ac9f11f40992f4", null ],
    [ "handler_position_defined", "d8/d66/points__manager_8py.html#acc79b0886c36ce60d758d8e185e8d9b4", null ],
    [ "name_get_point", "d8/d66/points__manager_8py.html#a493e76d1c1457c1b4792a1a52450cc23", null ],
    [ "name_position_defined", "d8/d66/points__manager_8py.html#a7483211cb7c3c69f8b8bed61a8a8bc40", null ],
    [ "node_name", "d8/d66/points__manager_8py.html#a758decdf4b0876859c99aeef844ca824", null ],
    [ "positions", "d8/d66/points__manager_8py.html#aac32297e7c101476da2eb932795a89b9", null ]
];