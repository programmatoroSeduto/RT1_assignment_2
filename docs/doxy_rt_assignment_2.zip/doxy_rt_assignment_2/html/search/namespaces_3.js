var searchData=
[
  ['points_5fmanager_148',['points_manager',['../dd/d7b/namespacepoints__manager.html',1,'']]]
];
