var searchData=
[
  ['points_5fmanager_2epy_158',['points_manager.py',['../d8/d66/points__manager_8py.html',1,'']]]
];
