var searchData=
[
  ['handler_5fget_5fpoint_221',['handler_get_point',['../dd/d7b/namespacepoints__manager.html#a9fd69118fff6c111e5ac9f11f40992f4',1,'points_manager']]],
  ['handler_5fposition_5fdefined_222',['handler_position_defined',['../dd/d7b/namespacepoints__manager.html#acc79b0886c36ce60d758d8e185e8d9b4',1,'points_manager']]]
];
