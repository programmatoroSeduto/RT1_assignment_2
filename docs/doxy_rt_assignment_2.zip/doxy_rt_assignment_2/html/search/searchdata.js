var indexSectionsWithContent =
{
  0: "/abcdefghiklmnoprstuwxyz",
  1: "bcgpruw",
  2: "bcghmprsuw",
  3: "cdfglmnprstuw",
  4: "acdehiklmnoprstuwxyz",
  5: "/crs"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

