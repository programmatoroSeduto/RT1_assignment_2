var user__interface_8py =
[
    [ "main", "dd/ddc/user__interface_8py.html#ac26bdb296b6776907b72c17ce5a1b24a", null ],
    [ "set_new_pos", "dd/ddc/user__interface_8py.html#aa9dc3b0346ac037400ae347eb6efb788", null ]
];